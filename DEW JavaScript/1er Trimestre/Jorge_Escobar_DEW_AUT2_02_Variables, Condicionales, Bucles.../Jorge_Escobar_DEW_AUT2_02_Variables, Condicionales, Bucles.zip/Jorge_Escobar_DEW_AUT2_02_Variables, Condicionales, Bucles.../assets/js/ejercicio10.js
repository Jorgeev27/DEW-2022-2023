/* 

10. Realizar un bucle for que actualice una variable i y otra j d
e la siguiente forma:

a) i comienza en 0, j comienza en 20.

b) El bucle debe parar cuando i sea mayor que 8 ó j sea menor que 0.

c) i se incrementa de 1 en 1, j se decrementa de 3 en 3.

d) Dentro del bucle sólo puede estar la sentencia console.log(i, j).

*/

for (let i = 0, j = 20; i < 9 && j < 0; i++, j - 3){
    console.log(i, j);
}