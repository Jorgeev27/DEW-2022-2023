/* 

3. Anida dos bucles for y muestra por la consola el resultado de los 
dos índices en cada iteración. Realiza 10 iteraciones en cada bucle.

*/

for(i = 1; i <= 11; i++){
    console.log(i);
    for(j = 1; j <=11; j++){
        console.log(j);
    }
}