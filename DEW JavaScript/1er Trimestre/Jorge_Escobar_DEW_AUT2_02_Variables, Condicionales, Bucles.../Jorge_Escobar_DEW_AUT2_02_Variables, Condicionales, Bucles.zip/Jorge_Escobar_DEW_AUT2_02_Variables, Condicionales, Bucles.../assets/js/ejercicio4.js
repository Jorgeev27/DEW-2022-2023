/* 

4. En este reto deberás mostrar el número posterior a un número 
introducido por el usuario. Deberás solicitar al usuario que 
introduzca 3 números, y para cada uno de ellos imprimir 
el número posterior.

*/

let numero1 = prompt("Introduzca el primer número");
let numero2 = prompt("Introduzca el segundo número");
let numero3 = prompt("Introduzca el tercer número");

console.log(parseInt(numero1) +1);
console.log(parseInt(numero2) +1);
console.log(parseInt(numero3) +1);