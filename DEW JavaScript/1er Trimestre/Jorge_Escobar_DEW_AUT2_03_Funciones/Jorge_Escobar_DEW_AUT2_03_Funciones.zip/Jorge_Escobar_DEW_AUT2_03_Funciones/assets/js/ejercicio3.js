/* 

3. Conversión de variables:  ¿Qué generan los siguientes códigos?

a. parseInt("15");

b. parseInt("15.5");

c. parseInt(15.5);

d. parseInt("true");

e. parseInt(true);

*/

let variable1 = parseInt("15");
document.write("La variable 1 da: " + variable1 + "<br/>");

let variable2 = parseInt("15.5");
document.write("La variable 2 da: " + variable2 + "<br/>");

let variable3 = parseInt(15.5);
document.write("La variable 3 da: " + variable3 + "<br/>");

let variable4 = parseInt("true");
document.write("La variable 4 da: " + variable4 + "<br/>");

let variable5 = parseInt(true);
document.write("La variable 5 da: " + variable5 + "<br/>");