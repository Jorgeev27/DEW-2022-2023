/* 

15. Programa que tenga una función que le pasemos un vector de N elementos 
y rota sus componentes un lugar hacia su derecha. Teniendo en 
cuenta que el último componente debe desplazarse al primer lugar.

*/

