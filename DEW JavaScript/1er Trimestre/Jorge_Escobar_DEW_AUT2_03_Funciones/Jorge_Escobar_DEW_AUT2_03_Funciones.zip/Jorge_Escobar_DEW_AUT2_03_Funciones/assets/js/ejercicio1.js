/* 

1. Resuelve estas expresiones y explica porqué devuelve ese valor:

   a. 2 > 3 +2
   b. 1 + false +3.5 
   c.4 * true + 2 
   d. 5 / 0 
   e. 10 > 2 > 0
   f. 15 < 3 * 10 
   g. 3 * hola + 2 
   h. 5 / “hola”
   i. π * 32 
   
*/

let variable1 = 2 > 3 + 2;
document.write("La variable 1 da: " + variable1 + "<br/>");

let variable2 = 1 + false + 3.5;
document.write("La variable 2 da: " + variable2 + "<br/>");

let variable3 = 4 * true + 2;
document.write("La variable 3 da: " + variable3 + "<br/>");

let variable4 = 5 / 0;
document.write("La variable 4 da: " + variable4 + "<br/>");

let variable5 = 10 > 2 > 0;
document.write("La variable 5 da: " + variable5 + "<br/>");

let variable6 = 15 < 3 * 10;
document.write("La variable 6 da: " + variable6 + "<br/>");

let variable7 = 3 * 'hola' + 2;
document.write("La variable 7 da: " + variable7 + "<br/>");

let variable8 = 5 / "hola";
document.write("La variable 8 da: " + variable8 + "<br/>");

let variable9 = "π" * 32;
document.write("La variable 9 da: " + variable9 + "<br/>");