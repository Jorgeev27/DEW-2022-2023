export interface Personajes{
    id: number,
    name: string,
    gender: string,
    description: string
}